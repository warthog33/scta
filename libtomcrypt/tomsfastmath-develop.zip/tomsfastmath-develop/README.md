tomsfastmath
============

See doc/tfm.pdf for a detailed documentation


Project Status
==============

master: [![Build Status](https://travis-ci.org/libtom/tomsfastmath.svg?branch=master)](https://travis-ci.org/libtom/tomsfastmath)

develop: [![Build Status](https://travis-ci.org/libtom/tomsfastmath.svg?branch=develop)](https://travis-ci.org/libtom/tomsfastmath)
