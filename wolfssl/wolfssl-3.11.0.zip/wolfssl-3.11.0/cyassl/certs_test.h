/* certs_test.h */

#include <wolfssl/certs_test.h>

#ifndef CYASSL_CERTS_TEST_H
    #define CYASSL_CERTS_TEST_H WOLFSSL_CERTS_TEST_H
#else
    #undef CYASSL_CERTS_TEST_H
    #define CYASSL_CERTS_TEST_H WOLFSSL_CERTS_TEST_H
#endif
