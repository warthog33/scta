/* ocsp.h for libcurl */

#include <wolfssl/openssl/ocsp.h>
