AES_128 c implementation
Date: 11-23-2011
By: Eric Peeters
Company: TI

The package contains the following files:
Implementation of the encryption and decryption function of the AES-128 as defined by FIPS-197 standard
- TI_aes_128.h
- TI_aes_128.c
- main_aes_128.c

Implementation of the encryption function only:
- TI_aes_128_encr_only.h
- TI_aes_128_encr_only.c
- main_aes_128_encr_only.c