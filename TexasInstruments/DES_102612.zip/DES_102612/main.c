/* --COPYRIGHT--,BSD
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/****************** DES Example Usuage Code*********************
*** by JH 4/27/12 -- Initial release***************************/

#include "DES.h"



void main(void){
  des_ctx dc;
  int i;
  unsigned char Data[16];
  unsigned char *cp,key[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
   unsigned char key1[8] = {0xda, 0xff, 0x37, 0x8c, 0x02, 0x46, 0x10, 0xfb};
   unsigned char key2[8] = {0x01,0x23,0x45,0x67,0x89,0xab,0xdc,0xfe};
  unsigned char x[24] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x8b, 0xe9, 0xed, 0xb5, 0x00, 0x00, 0x00}; //enc(RndB
  unsigned char v[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14,0x15,0x16}; 
  unsigned char y[8] = {0x05, 0x3F, 0x41,0xDA, 0x27, 0x26, 0xE4, 0x29};//RnadA
   unsigned char temp[8];
   unsigned char rb[] = {0x51, 0x5f, 0xbc, 0x06,0x10, 0xf4,0xaf,0x03};
   unsigned char ra[] = {0x79, 0xd4, 0x66, 0x29,0xf7,0xe1,0x12,0xc3};
unsigned char IV[8];
unsigned char IV2[8];
unsigned char t1,t2;



  cp = x;

 TripleDES_ENC_CBC( &dc,cp, 2, key,key1,key2,&IV[0]);
  
  TripleDES_DEC_CBC( &dc,cp, 2, key,key1,key2, &IV[0]);
  
/*
  Des_Key(&dc,key, ENDE);
  for(i=0;i<8;i++){
       IV[i] =  rb[i];
        IV2[i] =  rb[i];
     }
 Des_Dec (&dc,&rb[0],1);
 
    y[0] = x[1];
    t1= rb[0];
    rb[0] = rb[1];
    rb[1] = rb[2];
    rb[2] = rb[3];
    rb[3] = rb[4];
    rb[4] = rb[5];
    rb[5] = rb[6];
    rb[6] = rb[7];
    rb[7] =t1;
     y[1] = x[1];
     
     for(i=0;i<8;i++){
       v[i] = ra[i];
       v[8+i] = rb[i];
     } 
  y[1] = x[1];
  
  DES_Enc_CBC (&dc,&v[0],2, &IV[0]);
  
  temp[0] =x[1];
  DES_Dec_CBC (&dc,&v[0],2, &IV2[0]);
  DES_Enc_CBC (&dc,&temp[0],1, IV);
  DES_Enc_CBC (&dc,&y[0],1, IV);*/
  /* des_key(&dc,key, ENDE);
  cp = v;
   des_enc(&dc,cp,1);
     for (i=0; i <8; i++){
    v[i+8] ^= v[i];
  }
  cp+=8;
   des_enc(&dc,cp,1);
      for (i=8; i <16; i++){
    v[i+8] ^= v[i];
  }
   cp+=8;
   des_enc(&dc,cp,1);
   for (i=16; i <24; i++){
    v[i+8] ^= v[i];
  }
   cp+=8;
   des_enc(&dc,cp,1);
     
  temp[0] =x[1];*/
  /*des_key(&dc,key, ENDE);
  des_dec(&dc,cp,1); // dec(enk(RndB))
 
  temp[0] =x[1];
  temp[1] =x[2];
  temp[2] =x[3];
  temp[3] =x[4];
  temp[4] =x[5];
  temp[5] =x[6];
  temp[6] =x[7];
  temp[7] =x[0];
  
  for ( i=0; i<8; i++){
    Data[i] = y[i];
    Data[i+8] = temp[i];
  }
  cp = Data;
  
     des_key(&dc,key, ENDE);
  des_enc(&dc,cp,1); 
  des_key(&dc,key, ENDE);
  des_enc(&dc,&cp[8],1);

  
  des_key(&dc,key1, ENDE);
 /* for( i =0; i<8; i++){
    Data[i] = x[i];
  } */
  /*
  des_key(&dc, key, DE1);
  des_dec(&dc, cp,  1);
 
  for( i =0; i<8; i++){
    Data[i+8] = x[i];
  }*/
  /*
	des_dec(&dc,cp,1);
	
	

	cp = (char *) data;
	for(i=0;i<10;i++)data[i]=i;
	des_enc(&dc,cp,5); // Enc 5 blocks. 
	


	des_dec(&dc,cp,1);
	des_dec(&dc,cp+8,4);
	
	*/
  
  while (1);

}
